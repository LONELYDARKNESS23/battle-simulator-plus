---
name: Bug report / Ошибка
about: Report a reproducible problem in RIFT
title: ''
labels: bug
---

**What happened / Что произошло**

**Steps to reproduce / Как повторить**
1.
2.

**Expected result / Ожидаемый результат**

**Environment / Среда**
- OS:
- Python version (`python --version`):
- Browser:
- Scenario and game mode:
- Commander provider and model (if relevant):

**Screenshot or exported battle log / Снимок или журнал боя**
Attach only game data. Do not include API keys, private server addresses or your local config.
