## Change

What problem does this fix, and how does gameplay change?

## Validation

- [ ] Python tests pass.
- [ ] Frontend checks pass if frontend code changed.
- [ ] UI changes were checked in a browser.
- [ ] Local configuration, API keys and save files are not included.
